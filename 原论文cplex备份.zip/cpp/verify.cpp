#include <ilcplex/ilocplex.h>
#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <fstream>
#include <cmath>
#include <random>
#include "modelParam.h"

using namespace std;

// 读取模型参数（示例函数，实际应用中需根据数据格式调整）
ModelParams setParams(int numBerths,int numShips) {
    ModelParams params;

    params.numBerths = numBerths;
    params.numRows = 20;
    params.numSlotsPerRow = 24;
    params.numShips = numShips;
    params.planningHorizon = 168; // 一周（小时）
    
    params.width = 50.0;
    params.relativeHeight = 0.5;
    params.alpha = 1.0;
    params.beta = 20000.0;

    std::random_device rd;  // 用于获取种子
    std::mt19937 gen(rd()); // 随机数生成器

    std::uniform_int_distribution<> weight(60*1000, 300*1000);
    std::uniform_int_distribution<> saveCos(900,1200);
    std::uniform_int_distribution<> R(15,20);
    std::uniform_int_distribution<> unloadSpeed(5*1000,11*1000);
    std::uniform_real_distribution<> angel(35 * M_PI / 180,50* M_PI / 180);
    std::uniform_int_distribution<> density(2,5);
    std::uniform_int_distribution<> Tau_s(0,params.planningHorizon);


    //随机生成到达时间
    params.arrivalTime.resize(params.numShips);
    for(int s = 0 ; s< params.numShips;s++){
        params.arrivalTime[s] = Tau_s(gen);
        cout<<"船"<<s<<"到达时间："<<params.arrivalTime[s]<<endl;
    }

    // 生成随机卸载速度
    params.unloadingSpeed.resize(params.numShips);
    for (int s = 0; s < params.numShips; ++s) {
        params.unloadingSpeed[s].resize(params.numBerths);
        for (int b = 0; b < params.numBerths; ++b) {
            params.unloadingSpeed[s][b] = unloadSpeed(gen);  // 为每个船舶-泊位组合生成随机速度
            // cout<<params.unloadingSpeed[s][b]<<endl;
        }
    }
    //随机生成 转运成本
    params.transshipmentCost.resize(params.numShips);
    for(int s = 0; s < params.numShips ;s++){
        params.transshipmentCost[s].resize(params.numBerths);
        for(int b = 0; b < params.numBerths;b++){
            params.transshipmentCost[s][b].resize(params.numSlotsPerRow);
            for(int v = 0 ; v < params.numSlotsPerRow;v++){
                //由于程序中 v 是从0开始的 不需要-1
                params.transshipmentCost[s][b][v] = R(gen) + 0.5*v;
            }
        }
    }
    //同一行对同一艘船存储成本一致
    params.storageCost.resize(params.numShips);
    for(int s = 0; s < params.numShips ; s++){
        params.storageCost[s].resize(params.numRows);
        for(int r = 0; r < params.numRows;r++){
            params.storageCost[s][r] = saveCos(gen);
        }
    }

    // params.arrivalTime = vector<double>(params.numShips, 0.0);

    //初始化货物重量
    params.cargoWeight.resize(params.numShips);
    for(int s = 0 ; s < params.numShips;s++){
        params.cargoWeight[s] = weight(gen);
    }
   
    //初始化货物密度
    params.cargoDensity.resize(params.numShips);
    for(int s =0; s < params.numShips ; s++){
        params.cargoDensity[s] = density(gen);
    }
    
    //初始化安息角
    params.maxResponseAngle.resize(params.numShips);
    for(int s = 0 ;s < params.numShips; s++){
        params.maxResponseAngle[s]=angel(gen);
        // cout<<"angle"<<params.maxResponseAngle[s]<<endl;
    }
    
    
    // 计算每艘船需要的槽数 n_s（根据文档公式）
    params.requiredSlots.resize(params.numShips);
    for (int s = 0; s < params.numShips; s++) {
        double volume = params.cargoWeight[s] / params.cargoDensity[s];
        double term = 4.0 / (pow(params.width, 3) * params.relativeHeight * 
                            (2 - params.relativeHeight) * tan(params.maxResponseAngle[s]));
        double inside = volume + (1.0/12.0) * pow(params.width, 3) * 
                        pow(params.relativeHeight, 2) * (3 - 2 * params.relativeHeight) * 
                        tan(params.maxResponseAngle[s]);

        params.requiredSlots[s] = ceil(term * inside);
    }
    
    //槽数检验
    int totalRequiredSlots = 0;
    for (int s = 0; s < params.numShips; s++) {
        cout<<params.requiredSlots[s]<<endl;
        totalRequiredSlots += params.requiredSlots[s];
    }   
    cout<<"一共需要槽数：" <<totalRequiredSlots<<endl;
    int totalAvailableSlots = params.numRows * params.numSlotsPerRow;
    if (totalRequiredSlots > totalAvailableSlots) {
            cerr << "错误: 总需求槽数(" << totalRequiredSlots 
                << ")超过可用槽数(" << totalAvailableSlots << ")" << endl;
        exit(1);
    }

    return params;
}

// 主函数：构建并求解模型
int main() {
    
    //初始化CPLEX环境和模型
    IloEnv env;
    IloModel model(env);
    try {
        // 1. 读取模型参数
        ModelParams params = setParams(5,20);
        
    
        // 3. 定义决策变量
        // x_srv: 船舶s的货物是否分配到行r的槽v
        IloArray<IloArray<IloArray<IloBoolVar>>> x(env);
        // h_srv: 船舶s的货物是否结束于行r的槽v
        IloArray<IloArray<IloArray<IloBoolVar>>> h(env);
        // f_sr: 船舶s的货物是否分配到行r
        IloArray<IloArray<IloBoolVar>> f(env);
        // y_st: 船舶s的卸载是否在船舶t之前
        IloArray<IloArray<IloBoolVar>> y(env);
        // z_sb: 船舶s是否分配到泊位b
        IloArray<IloArray<IloBoolVar>> z(env);
        // e_s: 船舶s的卸载开始时间
        IloArray<IloNumVar> e(env);
        
        // 初始化变量
        for (int s = 0; s < params.numShips; s++) {
            // 初始化z_sb
            IloArray<IloBoolVar> z_s(env, params.numBerths);
            for (int b = 0; b < params.numBerths; b++) {
                string z_name = "z_" + to_string(s) + "_" + to_string(b);
                z_s[b]=IloBoolVar(env,z_name.c_str());
            }
            z.add(z_s);
            
            // 初始化y_st
            IloArray<IloBoolVar> y_s(env,params.numShips);
            for (int t = 0; t < params.numShips; t++) {
                string y_name = "y_" + to_string(s) +"_"+to_string(t);
                y_s[t]= IloBoolVar(env,y_name.c_str());
            }
            y.add(y_s);
            
            // 初始化f_sr
            IloArray<IloBoolVar> f_s(env,params.numRows);
            for (int r = 0; r < params.numRows; r++) {
                string f_name = "f_" + to_string(s) + "_" + to_string(r);
                f_s[r] = IloBoolVar(env,f_name.c_str());
            }
            f.add(f_s);
            
            // 初始化e_s
            e.add(IloNumVar(env, params.arrivalTime[s], params.planningHorizon));
            
            // 初始化x_srv和h_srv

            
            // 初始化x[s]（二维数组）
            IloArray<IloArray<IloBoolVar>> x_s(env);
            x_s = IloArray<IloArray<IloBoolVar>>(env, params.numRows);
            for (int r = 0; r < params.numRows; r++) {
                x_s[r] = IloArray<IloBoolVar>(env, params.numSlotsPerRow);
        
                // 初始化x[s][r][v]（变量）
                for (int v = 0; v < params.numSlotsPerRow; v++) {
                    string x_name = "x_" + to_string(s) + "_" + to_string(r) + "_" + to_string(v);
                    x_s[r][v] = IloBoolVar(env, x_name.c_str());
                }
            }
            // 将x_s添加到x数组
            x.add(x_s);
            // 同理初始化h数组
            IloArray<IloArray<IloBoolVar>> h_s(env);
            h_s = IloArray<IloArray<IloBoolVar>>(env, params.numRows);
            for (int r = 0; r < params.numRows; r++) {
                h_s[r] = IloArray<IloBoolVar>(env, params.numSlotsPerRow);
                for (int v = 0; v < params.numSlotsPerRow; v++) {
                    string h_name = "h_" + to_string(s) + "_" + to_string(r) + "_" + to_string(v);
                    h_s[r][v] = IloBoolVar(env, h_name.c_str());
                }
            }
            h.add(h_s);
            
        }
        
        // 4. 构建目标函数：最小化总转运成本、存储成本和靠泊时间
        IloExpr objExpr(env);
        
        // 总转运成本
        for (int s = 0; s < params.numShips; s++) {
            for (int b = 0; b < params.numBerths; b++) {
                for (int r = 0; r < params.numRows; r++) {
                    for (int v = 0; v < params.numSlotsPerRow; v++) {
                        // int slotIndex = r * params.numSlotsPerRow + v;
                        objExpr += params.transshipmentCost[s][b][v] * 
                                  params.cargoWeight[s] / params.requiredSlots[s] * 
                                  x[s][r][v] * z[s][b];
                    }
                }
            }
        }
        
        // 总存储成本
        for (int s = 0; s < params.numShips; s++) {
            for (int r = 0; r < params.numRows; r++) {
                for (int v = 0; v < params.numSlotsPerRow; v++) {
                    objExpr += params.storageCost[s][r] * x[s][r][v];
                }
            }
        }


       IloExpr berthTime(env);
        // 正确计算每艘船的靠泊时间（考虑泊位分配）
        for (int s = 0; s < params.numShips; s++) {
            IloExpr singleBerth(env);
            singleBerth += e[s] - params.arrivalTime[s];
    
            // 仅累加分配泊位的卸载时间
            for (int b = 0; b < params.numBerths; b++) {
                double speed = params.unloadingSpeed[s][b];
                if (speed <= 0) speed = 1.0; // 防除零
                singleBerth += (params.cargoWeight[s] / speed) * z[s][b];
            }
            berthTime += singleBerth;
            singleBerth.end();
        }
        // 应用权重
        objExpr = params.alpha * objExpr + params.beta * berthTime; // 注意：目标函数公式需根据文档调整权重应用方式
        
        model.add(IloMinimize(env, objExpr));
        berthTime.end();
        objExpr.end();
        
        // 5. 添加约束条件
        
        //约束(3.8): 每艘船分配到一个泊位
        for (int s = 0; s < params.numShips; s++) {
            IloExpr con(env);
            for (int b = 0; b < params.numBerths; b++) {
                con += z[s][b];
            }
            model.add(con == 1);
            con.end();
        }
        
        // 约束(3.11): 每艘船占用足够的槽数
        for (int s = 0; s < params.numShips; s++) {
            IloExpr con(env);
            for (int r = 0; r < params.numRows; r++) {
                for (int v = 0; v < params.numSlotsPerRow; v++) {
                    con += x[s][r][v];
                }
            }
            // cout<<params.requiredSlots[s]<<endl;
            model.add(con == params.requiredSlots[s]);
            con.end();
        }
        
        // 约束(3.12): 每个槽最多放一种货物

        for (int r = 0; r < params.numRows; r++) {
            for (int v = 0; v < params.numSlotsPerRow; v++) {
                IloExpr con(env);
                for (int s = 0; s < params.numShips; s++) {
                    con += x[s][r][v];
                }
                model.add(con <= 1);
                con.end();
            }
        }
        
        // 约束(3.13): 每艘船的货物存储在同一行
        for (int s = 0; s < params.numShips; s++) {
            IloExpr con(env);
            for (int r = 0; r < params.numRows; r++) {
                con += f[s][r];
            }
            model.add(con == 1);
            con.end();
        }
        
        // 约束(3.14): x_srv与f_sr的关联
        for (int s = 0; s < params.numShips; s++) {
            for (int r = 0; r < params.numRows; r++) {
                IloExpr con(env);
                for (int v = 0; v < params.numSlotsPerRow; v++) {
                    con += x[s][r][v];
                }
                model.add(con <= params.numSlotsPerRow * f[s][r]);
                con.end();
            }
        }
        
        // 约束(12)-(14): 存储槽的连续性（简化实现，完整逻辑需按文档详细处理）
        for (int s = 0; s < params.numShips; s++) {
            for (int r = 0; r < params.numRows; r++) {
                IloExpr con(env);
                for (int v = 0; v < params.numSlotsPerRow; v++) {
                    con += h[s][r][v];
                }
                model.add(con == f[s][r]);
                con.end();
                
                // 约束(13): 最后一个槽的h_srv约束
                model.add(x[s][r][params.numSlotsPerRow-1] <= h[s][r][params.numSlotsPerRow-1]);
                
                // 约束(14): 中间槽的连续性约束
                for (int v = 0; v < params.numSlotsPerRow-1; v++) {
                    model.add(x[s][r][v] - x[s][r][v+1] <= h[s][r][v]);
                }
            }
        }
        
        // 6. 线性化处理（约束24-36和39-45）
        // 此处需完整实现线性化逻辑，以下为简化示例
        IloArray<IloArray<IloArray<IloBoolVar>>> omega(env);
        IloArray<IloArray<IloArray<IloBoolVar>>> lambda(env);
        IloArray<IloArray<IloArray<IloBoolVar>>> mu(env);
        IloArray<IloArray<IloArray<IloNumVar>>> zeta(env);
        IloArray<IloArray<IloArray<IloNumVar>>> eta(env);
        
        // 初始化线性化变量
        for (int s = 0; s < params.numShips; s++) {
            // 初始化s维度的数组
            IloArray<IloArray<IloBoolVar>> omega_s(env, params.numShips);
            IloArray<IloArray<IloBoolVar>> lambda_s(env, params.numShips);
            IloArray<IloArray<IloBoolVar>> mu_s(env, params.numShips);
            IloArray<IloArray<IloNumVar>> zeta_s(env, params.numShips);
            IloArray<IloArray<IloNumVar>> eta_s(env, params.numShips);
            
            for (int t = 0; t < params.numShips; t++) {
                // 初始化t维度的数组
                IloArray<IloBoolVar> omega_st(env, params.numBerths);
                IloArray<IloBoolVar> lambda_st(env, params.numBerths);
                IloArray<IloBoolVar> mu_st(env, params.numBerths);
                IloArray<IloNumVar> zeta_st(env, params.numBerths);
                IloArray<IloNumVar> eta_st(env, params.numBerths);
                
                for (int b = 0; b < params.numBerths; b++) {
                    // 生成变量名称
                    string omega_name = "omega_" + to_string(s) + "_" + to_string(t) + "_" + to_string(b);
                    string lambda_name = "lambda_" + to_string(s) + "_" + to_string(t) + "_" + to_string(b);
                    string mu_name = "mu_" + to_string(s) + "_" + to_string(t) + "_" + to_string(b);
                    
                    // 初始化变量并设置名称
                    omega_st[b] = IloBoolVar(env, omega_name.c_str());
                    lambda_st[b] = IloBoolVar(env, lambda_name.c_str());
                    mu_st[b] = IloBoolVar(env, mu_name.c_str());
                    
                    string zeta_name = "zeta_" + to_string(s) + "_" + to_string(t) + "_" + to_string(b);
                    string eta_name = "eta_" + to_string(s) + "_" + to_string(t) + "_" + to_string(b);
                    zeta_st[b] = IloNumVar(env, 0, params.planningHorizon * params.numShips, zeta_name.c_str());
                    eta_st[b] = IloNumVar(env, 0, params.planningHorizon * params.numShips, eta_name.c_str());
                }
                
                // 将t维度的数组添加到s维度数组
                omega_s[t] = omega_st;
                lambda_s[t] = lambda_st;
                mu_s[t] = mu_st;
                zeta_s[t] = zeta_st;
                eta_s[t] = eta_st;
            }
            
            // 将s维度的数组添加到全局数组
            omega.add(omega_s);
            lambda.add(lambda_s);
            mu.add(mu_s);
            zeta.add(zeta_s);
            eta.add(eta_s);
        }
        
        // 添加线性化约束(24-36)
        for (int s = 0; s < params.numShips; s++) {
            for (int t = 0; t < params.numShips; t++) {
                if (s == t) continue;
                for (int b = 0; b < params.numBerths; b++) {
                    // 约束(24): lambda + mu - omega = 0
                    model.add(lambda[s][t][b] + mu[s][t][b] - omega[s][t][b] == 0);
                    
                    // 约束(25-26): omega <= z_sb 和 omega <= z_tb
                    model.add(omega[s][t][b] <= z[s][b]);
                    model.add(omega[s][t][b] <= z[t][b]);
                    
                    // // 约束(27): omega >= z_sb + z_tb - 1
                    model.add(omega[s][t][b] >= z[s][b] + z[t][b] - 1);
                    // 约束(28-33): lambda和mu的线性化约束
                    // mu[s][t][b] = 1 表示s和t在同一泊位b，且s在t之后
                    model.add(mu[s][t][b] <= omega[s][t][b]);
                    model.add(mu[s][t][b] <= y[s][t]);
                    model.add(mu[s][t][b] >= omega[s][t][b] + y[s][t] - 1);
                    
                    // lambda[s][t][b] = 1 表示s和t在同一泊位b，且s在t之前
                    model.add(lambda[s][t][b] <= omega[s][t][b]);
                    model.add(lambda[s][t][b] <= 1 - y[s][t]); // 修正此处
                    model.add(lambda[s][t][b] >= omega[s][t][b] + (1 - y[s][t]) - 1);
                }
            }
        }
        
        // 添加线性化约束(39-45)
        double M1 = params.planningHorizon + 150000; // 足够大的常数
        for (int s = 0; s < params.numShips; s++) {
            for (int t = 0; t < params.numShips; t++) {
                if (s == t) continue;
                for (int b = 0; b < params.numBerths; b++) {
                    // 约束(39): zeta + (M1 - gamma_s/p_sb)*omega - eta - M1*lambda >= 0

                    // double gammaOverP = params.cargoWeight[s] / params.unloadingSpeed[s][b];

                    double cargoWeight = params.cargoWeight[s];
                    double unloadSpeed = params.unloadingSpeed[s][b];
                    if (unloadSpeed <= 0) unloadSpeed = 1.0; // 设置安全默认值
                    double gammaOverP = cargoWeight / unloadSpeed;
                    
                    model.add(zeta[s][t][b] + (M1 - gammaOverP) * omega[s][t][b] - 
                             eta[s][t][b] - M1 * lambda[s][t][b] >= 0);
                    
                    // 约束(40-41): zeta和eta的范围约束
                    model.add(e[t] + M1 * (omega[s][t][b] - 1) <= zeta[s][t][b]);
                    model.add(zeta[s][t][b] <= e[t] + M1 * (1 - omega[s][t][b]));

                    model.add(e[s] + M1 * (omega[s][t][b] - 1) <= eta[s][t][b]);
                    model.add(eta[s][t][b] <= e[s] + M1 * (1 - omega[s][t][b]));
                    
                    // 约束(42-43): zeta和eta的上界
                    model.add(zeta[s][t][b] <= M1 * omega[s][t][b]);
                    model.add(eta[s][t][b] <= M1 * omega[s][t][b]);

                    // model.add(zeta[s][t][b] - eta[s][t][b] <= M1 * mu[s][t][b]);
                    // model.add(eta[s][t][b] - zeta[s][t][b] <= M1 * (1 - mu[s][t][b]));
                }
            }
        }
        // 7. 求解模型
        IloCplex cplex(model);
        cout <<"导出模型"<<endl;
        // cout <<"导出模型"<<endl;
        cplex.setOut(env.getNullStream()); // 关闭输出
        cplex.setParam(IloCplex::TiLim, 3600); // 设置时间限制为1小时
        
        if (cplex.solve()) {
            env.out() << "模型求解成功！" << endl;
            env.out() << "目标函数值: " << cplex.getObjValue() << endl;
            
            // 输出部分决策变量结果
            env.out() << "\n泊位分配结果(z_sb):" << endl;
            for (int s = 0; s < params.numShips; s++) {
                for (int b = 0; b < params.numBerths; b++) {
                    if (cplex.getValue(z[s][b]) > 0.5) {
                        env.out() << "船舶 " << s << " 分配到泊位 " << b << endl;
                    }
                }
            }
            
            env.out() << "\n存储行分配结果(f_sr):" << endl;
            for (int s = 0; s < params.numShips; s++) {
                for (int r = 0; r < params.numRows; r++) {
                    if (cplex.getValue(f[s][r]) > 0.5) {
                        env.out() << "船舶 " << s << " 存储在行 " << r << endl;
                    }
                }
            }
            
            env.out() << "\n卸载开始时间(e_s):" << endl;
            for (int s = 0; s < params.numShips; s++) {
                env.out() << "船舶 " << s << ": " << cplex.getValue(e[s]) << " 小时" << endl;
            }
        } else {
            
            env.out() << "求解状态: " << cplex.getStatus() << endl;
            env.out() << "不可行解分析:" << endl;
            cplex.exportModel("infeasible_model.lp");
            // 尝试找到导致不可行的关键约束
            IloNumVarArray vars(env);
            IloRangeArray ranges(env);
            // cplex.getInfeasible(vars, ranges);
            env.out() << "不可行变量数: " << vars.getSize() << endl;
            env.out() << "不可行约束数: " << ranges.getSize() << endl;

        }
        
        // 8. 释放资源
        cplex.end();
        model.end();
        env.end();
        
        return 0;
    } catch (IloException& e) {
        cerr << "CPLEX异常: " << e << endl;
    } catch (...) {
        cerr << "未知异常" << endl;
    }
    
    return 1;
}