#include <iostream>
#include <ilcplex/ilocplex.h>

ILOSTLBEGIN

int main() {
    IloEnv env;
    try {
        // 创建模型
        IloModel model(env);
        
        // 定义决策变量
        IloNumVar x(env, 0.0, IloInfinity, ILOFLOAT, "x");
        IloNumVar y(env, 0.0, IloInfinity, ILOFLOAT, "y");
        
        // 设置目标函数：最大化 3x + 2y
        IloObjective obj = IloMaximize(env, 3 * x + 2 * y);
        model.add(obj);
        
        // 添加约束条件
        model.add(2 * x + y <= 100);    // 约束1
        model.add(x + 3 * y <= 120);    // 约束2
        
        // 创建求解器
        IloCplex cplex(model);
        
        // 设置求解参数（可选）
        cplex.setParam(IloCplex::Param::MIP::Display, 2);
        cplex.setParam(IloCplex::RootAlg, IloCplex::Primal); // 显式设置求解算法
        
        // 求解模型
        if (!cplex.solve()) {
            env.error() << "求解失败，状态码: " << cplex.getStatus() << std::endl;
            throw(-1);
        }
        
        // 输出结果
        env.out() << "求解状态: " << cplex.getStatus() << std::endl;
        env.out() << "最优目标值: " << cplex.getObjValue() << std::endl;
        env.out() << "最优解: x = " << cplex.getValue(x) 
                  << ", y = " << cplex.getValue(y) << std::endl;
        
        // 验证约束条件
        env.out() << "验证约束条件:" << std::endl;
        env.out() << "2x + y = " << 2 * cplex.getValue(x) + cplex.getValue(y) << " <= 100" << std::endl;
        env.out() << "x + 3y = " << cplex.getValue(x) + 3 * cplex.getValue(y) << " <= 120" << std::endl;
        
    } catch (IloException& e) {
        std::cerr << "CPLEX异常: " << e << std::endl;
    } catch (...) {
        std::cerr << "未知异常!" << std::endl;
    }
    
    env.end(); // 释放资源
    return 0;
}